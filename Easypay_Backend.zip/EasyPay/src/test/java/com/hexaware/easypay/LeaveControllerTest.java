package com.hexaware.easypay;

import com.hexaware.easypay.controller.LeaveController;
import com.hexaware.easypay.dto.EmployeeDTO;
import com.hexaware.easypay.dto.LeaveDTO;
import com.hexaware.easypay.enumeration.LeaveStatus;
import com.hexaware.easypay.enumeration.LeaveType;
import com.hexaware.easypay.serviceInterface.ILeaveService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class LeaveControllerTest {

    @InjectMocks
    private LeaveController controller;

    @Mock
    private ILeaveService service;

    private LeaveDTO leaveDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        leaveDTO = new LeaveDTO();
        leaveDTO.setLeaveId(1);
        leaveDTO.setEmpId(101);
        leaveDTO.setLeaveType(LeaveType.SICK);
        leaveDTO.setStartDate("2025-07-18");
        leaveDTO.setEndDate("2025-07-20");
        leaveDTO.setStatus(LeaveStatus.PENDING);

        EmployeeDTO empDTO = new EmployeeDTO();
        empDTO.setEmpId(101);
        empDTO.setEmpName("John");
        empDTO.setStatus("Active");
        leaveDTO.setEmployee(empDTO);
    }

    @Test
    void testRequestLeave() {
        when(service.requestLeave(leaveDTO)).thenReturn("Leave requested successfully");

        ResponseEntity<String> response = controller.requestLeave(leaveDTO);

        assertEquals(201, response.getStatusCodeValue());
        assertEquals("Leave requested successfully", response.getBody());
        assertTrue(response.getHeaders().containsKey("header-info"));
    }

    @Test
    void testViewLeavesByDepartment() {
        List<LeaveDTO> leaves = new ArrayList<>();
        leaves.add(leaveDTO);

        when(service.getLeavesByDepartmentAndActiveEmployees(10)).thenReturn(leaves);

        ResponseEntity<List<LeaveDTO>> response = controller.viewLeavesByDepartment(10);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1, response.getBody().size());
        assertEquals(101, response.getBody().get(0).getEmpId());
    }

    @Test
    void testGetMyLeaves() {
        List<LeaveDTO> leaves = new ArrayList<>();
        leaves.add(leaveDTO);

        when(service.getMyLeaves(101)).thenReturn(leaves);

        ResponseEntity<List<LeaveDTO>> response = controller.getMyLeaves(101);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1, response.getBody().size());
        assertEquals("SICK", response.getBody().get(0).getLeaveType().toString());
    }

    @Test
    void testGetTeamLeaves() {
        List<LeaveDTO> teamLeaves = new ArrayList<>();
        teamLeaves.add(leaveDTO);

        when(service.getTeamLeaves(500)).thenReturn(teamLeaves);

        ResponseEntity<List<LeaveDTO>> response = controller.getTeamLeaves(500);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1, response.getBody().size());
        assertEquals(101, response.getBody().get(0).getEmpId());
    }

    @Test
    void testApproveLeave() {
        when(service.approveLeave(1)).thenReturn("Leave approved successfully");

        ResponseEntity<String> response = controller.approveLeave(1);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Leave approved successfully", response.getBody());
        assertTrue(response.getHeaders().containsKey("header-info"));
    }

    @Test
    void testRejectLeave() {
        when(service.rejectLeave(1)).thenReturn("Leave rejected successfully");

        ResponseEntity<String> response = controller.rejectLeave(1);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Leave rejected successfully", response.getBody());
        assertTrue(response.getHeaders().containsKey("header-info"));
    }
}
