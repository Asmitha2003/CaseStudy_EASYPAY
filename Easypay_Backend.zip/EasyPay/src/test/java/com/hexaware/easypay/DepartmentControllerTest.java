package com.hexaware.easypay;

import com.hexaware.easypay.controller.DepartmentController;
import com.hexaware.easypay.dto.DepartmentDTO;
import com.hexaware.easypay.entity.Employee;
import com.hexaware.easypay.repository.DepartmentRepository;
import com.hexaware.easypay.serviceInterface.IDepartmentService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.converter.json.MappingJacksonValue;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DepartmentControllerTest {

    @InjectMocks
    private DepartmentController controller;

    @Mock
    private IDepartmentService service;

    @Mock
    private DepartmentRepository departmentRepo;

    private DepartmentDTO mockDept;
    private Employee mockManager;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        mockDept = new DepartmentDTO();
        mockDept.setDeptId(1);
        mockDept.setDeptName("IT");
        mockDept.setManagerName("Alice");

        mockManager = new Employee();
        mockManager.setEmpId(101);
        mockManager.setEmpName("Alice");
    }

    @Test
    void testAddDepartment() {
        when(service.addDepartment(mockDept)).thenReturn("Department added successfully");

        String result = controller.addDepartment(mockDept);

        assertEquals("Department added successfully", result);
    }

    @Test
    void testAssignManager() {
        when(service.assignManager(1, 101)).thenReturn("Manager assigned successfully");

        String result = controller.assignManager(1, 101);

        assertEquals("Manager assigned successfully", result);
    }

    @Test
    void testGetAllDepartments() {
        when(service.getAllDepartments()).thenReturn(Arrays.asList(mockDept));

        List<DepartmentDTO> list = controller.getAllDepartments();

        assertEquals(1, list.size());
        assertEquals("IT", list.get(0).getDeptName());
        assertEquals("Alice", list.get(0).getManagerName());
    }

    @Test
    void testGetDepartmentById() {
        when(service.getDepartmentById(1)).thenReturn(mockDept);

        DepartmentDTO result = controller.getDepartmentById(1);

        assertNotNull(result);
        assertEquals("IT", result.getDeptName());
    }

    @Test
    void testUpdateDepartment() {
        when(service.updateDepartment(1, mockDept)).thenReturn("Department updated successfully");

        String result = controller.updateDepartment(1, mockDept);

        assertEquals("Department updated successfully", result);
    }

    @Test
    void testDeleteDepartment() {
        when(service.deleteDepartment(1)).thenReturn("Department deleted successfully");

        String result = controller.deleteDepartment(1);

        assertEquals("Department deleted successfully", result);
    }

    @Test
    void testGetEmployeesByDeptId() {
        List<Employee> employees = Arrays.asList(mockManager);
        when(service.getEmployeesByDeptId(1)).thenReturn(employees);

        MappingJacksonValue result = controller.getEmployeesByDeptId(1);
        assertNotNull(result.getValue());
        List<Employee> resultList = (List<Employee>) result.getValue();
        assertEquals(1, resultList.size());
        assertEquals("Alice", resultList.get(0).getEmpName());
    }

    @Test
    void testGetDepartmentCount() {
        when(departmentRepo.count()).thenReturn(4L);

        long result = controller.getDepartmentCount();

        assertEquals(4, result);
    }
}

