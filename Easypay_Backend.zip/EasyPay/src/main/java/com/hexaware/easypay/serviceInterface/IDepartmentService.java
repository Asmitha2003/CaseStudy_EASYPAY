package com.hexaware.easypay.serviceInterface;

import com.hexaware.easypay.dto.DepartmentDTO;
import com.hexaware.easypay.entity.Employee;

import java.util.List;

public interface IDepartmentService {
	String addDepartment(DepartmentDTO dto);

	String assignManager(int deptId, int managerId);

	List<DepartmentDTO> getAllDepartments();

	DepartmentDTO getDepartmentById(int id);

	String deleteDepartment(int id);

	List<Employee> getEmployeesByDeptId(int deptId);

	String updateDepartment(int id, DepartmentDTO dto);
	
}
