package com.hexaware.easypay.enumeration;

public enum UserRole 
{
    ADMIN,
    MANAGER,
    EMPLOYEE
}