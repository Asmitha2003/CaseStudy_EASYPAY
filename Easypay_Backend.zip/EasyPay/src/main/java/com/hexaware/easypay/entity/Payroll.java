package com.hexaware.easypay.entity;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "payroll")
public class Payroll {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int payrollId;

    @Column(name = "basic_salary", nullable = false)
    private double basicSalary;

    @Column(name = "bonuses", nullable = false)
    private double bonuses = 0;

    @Column(name = "allowances", nullable = false)
    private double allowances;

    @Column(name = "deductions", nullable = false)
    private double deductions;

    @Column(name = "net_salary", nullable = false)
    private double netSalary;

    @Column(name = "pay_date", nullable = false)
    private Date payDate;

    @NotNull(message = "Employee cannot be null")
    @ManyToOne
    @JoinColumn(name = "emp_id", nullable = false)
    private Employee employee;

    public Payroll() {}

    public Payroll(int payrollId, double basicSalary, double bonuses, double allowances,
                   double deductions, double netSalary, Date payDate, Employee employee) {
        this.payrollId = payrollId;
        this.basicSalary = basicSalary;
        this.bonuses = bonuses;
        this.allowances = allowances;
        this.deductions = deductions;
        this.netSalary = netSalary;
        this.payDate = payDate;
        this.employee = employee;
    }

    public int getPayrollId() {
        return payrollId;
    }

    public void setPayrollId(int payrollId) {
        this.payrollId = payrollId;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public double getBonuses() {
        return bonuses;
    }

    public void setBonuses(double bonuses) {
        this.bonuses = bonuses;
    }

    public double getAllowances() {
        return allowances;
    }

    public void setAllowances(double allowances) {
        this.allowances = allowances;
    }

    public double getDeductions() {
        return deductions;
    }

    public void setDeductions(double deductions) {
        this.deductions = deductions;
    }

    public double getNetSalary() {
        return netSalary;
    }

    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }

    public Date getPayDate() {
        return payDate;
    }

    public void setPayDate(Date payDate) {
        this.payDate = payDate;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    @Override
    public String toString() {
        return "Payroll [payrollId=" + payrollId + ", basicSalary=" + basicSalary +
                ", bonuses=" + bonuses + ", allowances=" + allowances +
                ", deductions=" + deductions + ", netSalary=" + netSalary +
                ", payDate=" + payDate + ", employee=" + employee + "]";
    }
}
