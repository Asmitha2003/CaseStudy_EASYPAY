package com.hexaware.easypay.serviceImplementation;

import com.hexaware.easypay.dto.EmployeeDTO;
import com.hexaware.easypay.dto.LeaveDTO;
import com.hexaware.easypay.entity.Employee;
import com.hexaware.easypay.entity.Leaves;
import com.hexaware.easypay.enumeration.LeaveStatus;
import com.hexaware.easypay.exception.LeaveNotFoundException;
import com.hexaware.easypay.mapper.LeaveMapper;
import com.hexaware.easypay.repository.EmployeeRepository;
import com.hexaware.easypay.repository.LeaveRepository;
import com.hexaware.easypay.serviceInterface.ILeaveService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class LeaveService implements ILeaveService {

    @Autowired
    private LeaveRepository leaveRepo;

    @Autowired
    private EmployeeRepository employeeRepo;

    @Autowired
    private LeaveMapper leaveMapper;

    @Override
    public String requestLeave(LeaveDTO leaveDTO) 
    {
        Employee employee = employeeRepo.findById(leaveDTO.getEmpId()).orElse(null);
        if (employee == null) 
        {
            return "Employee not found";
        }

        
        Leaves leave = leaveMapper.dtoToLeave(leaveDTO);
        leave.setStatus(LeaveStatus.PENDING);
        leave.setEmployee(employee);
        
        leaveRepo.save(leave);
        return "Leave requested successfully";
    }
    
    

    @Override
    public List<LeaveDTO> getMyLeaves(int empId) 
    {
        List<Leaves> leaves = leaveRepo.findByEmployeeEmpId(empId);
        List<LeaveDTO> leaveDTOs = new ArrayList<>();

        for (int i = 0; i < leaves.size(); i++) 
        {
            Leaves leave = leaves.get(i);
            LeaveDTO dto = leaveMapper.leaveToDto(leave);
            leaveDTOs.add(dto);
        }

        return leaveDTOs;
    }

    
    @Override
    public List<LeaveDTO> getTeamLeaves(int managerId) {
        Employee manager = employeeRepo.findById(managerId).orElse(null);
        List<LeaveDTO> leaveDTOs = new ArrayList<>();

        if (manager == null) {
            return leaveDTOs;
        }

        int departmentId = manager.getDepartment().getDeptId();
        List<Leaves> teamLeaves = leaveRepo.findByEmployeeDepartmentDeptIdAndEmployeeStatus(departmentId, "Active");


        for (Leaves leave : teamLeaves) {
            if (leave.getEmployee().getEmpId() != managerId) {
                LeaveDTO dto = leaveMapper.leaveToDto(leave);

                Employee emp = leave.getEmployee();
                EmployeeDTO empDTO = new EmployeeDTO();
                empDTO.setEmpId(emp.getEmpId());
                empDTO.setEmpName(emp.getEmpName());
                empDTO.setEmail(emp.getEmail()); 

                dto.setEmployee(empDTO); // 

                leaveDTOs.add(dto);
            }
        }

        return leaveDTOs;
    }

    
    
    @Override
    public String approveLeave(int leaveId) 
    {
        Leaves leave = leaveRepo.findById(leaveId)
                .orElseThrow(() -> new LeaveNotFoundException(leaveId));
        
        leave.setStatus(LeaveStatus.APPROVED);
        leaveRepo.save(leave);
        return "Leave approved successfully";
    }

    @Override
    public String rejectLeave(int leaveId) 
    {
        Leaves leave = leaveRepo.findById(leaveId)
                .orElseThrow(() -> new LeaveNotFoundException(leaveId));
        
        leave.setStatus(LeaveStatus.REJECTED);
        leaveRepo.save(leave);
        return "Leave rejected successfully";
    }
    
    @Override
    public List<LeaveDTO> getLeavesByDepartmentAndActiveEmployees(int deptId) {
        List<Leaves> leaveList = leaveRepo.findByEmployee_Department_DeptIdAndEmployee_Status(deptId, "Active");
        return leaveList.stream().map(leaveMapper::leaveToDto).collect(Collectors.toList());
    }


}