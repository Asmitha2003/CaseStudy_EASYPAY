package com.hexaware.easypay.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hexaware.easypay.dto.EmployeeDTO;
import com.hexaware.easypay.entity.Employee;

@Component
public class EmployeeMapper {
	
        @Autowired
        private ModelMapper modelMapper;

        public Employee dtoToEmployee(EmployeeDTO dto) 
        {
            return modelMapper.map(dto, Employee.class);
        }

       
        public EmployeeDTO EmployeeToDTO(Employee employee) {
            EmployeeDTO dto = new EmployeeDTO();
            dto.setEmpId(employee.getEmpId());
            dto.setEmpName(employee.getEmpName());
            dto.setEmail(employee.getEmail());
            dto.setPhone(employee.getPhone());
            dto.setAddress(employee.getAddress());
            dto.setGender(employee.getGender());
            dto.setDesignation(employee.getDesignation());
            dto.setJoiningDate(employee.getJoiningDate());
            dto.setStatus(employee.getStatus());
            dto.setSalary(employee.getSalary());

            if (employee.getDepartment() != null) {
                dto.setDeptId(employee.getDepartment().getDeptId());
                dto.setDeptName(employee.getDepartment().getDeptName());
            }

            return dto;
        }


       
}