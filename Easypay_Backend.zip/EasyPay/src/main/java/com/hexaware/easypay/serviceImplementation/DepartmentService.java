package com.hexaware.easypay.serviceImplementation;

import com.hexaware.easypay.dto.DepartmentDTO;
import com.hexaware.easypay.entity.Department;
import com.hexaware.easypay.entity.Employee;
import com.hexaware.easypay.exception.DepartmentNotFoundException;
import com.hexaware.easypay.exception.ResourceNotFoundException;
import com.hexaware.easypay.mapper.DepartmentMapper;
import com.hexaware.easypay.repository.DepartmentRepository;
import com.hexaware.easypay.repository.EmployeeRepository;
import com.hexaware.easypay.serviceInterface.IDepartmentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DepartmentService implements IDepartmentService {

    @Autowired
    private DepartmentRepository repository;

    @Autowired
    private DepartmentMapper mapper;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public String addDepartment(DepartmentDTO dto) {
        Department department = mapper.dtoToDepartment(dto);
        repository.save(department);
        return "Department added successfully";
    }

    @Override
    public String assignManager(int deptId, int managerId) 
    {
        Department department = repository.findById(deptId)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found"));

        Employee manager = employeeRepository.findById(managerId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        if (!manager.getDesignation().equalsIgnoreCase("Manager"))
        {
            throw new IllegalArgumentException("Selected employee is not a Manager");
        }

        department.setManager(manager);
        repository.save(department);
        return "Manager assigned successfully";
    }

    
    @Override
    public List<DepartmentDTO> getAllDepartments() {
        List<Department> departmentList = repository.findAll();
        if (departmentList.isEmpty()) {
            throw new DepartmentNotFoundException("No departments found");
        }

        List<DepartmentDTO> dtoList = new ArrayList<>();
        for (Department department : departmentList) {
            DepartmentDTO dto = mapper.departmentToDto(department);

            // ✅ Set manager name if available
            if (department.getManager() != null) {
                dto.setManagerName(department.getManager().getEmpName());
            }

            dtoList.add(dto);
        }
        return dtoList;
    }


    @Override
    public DepartmentDTO getDepartmentById(int id) 
    {
        Department department = repository.findById(id).orElse(null);
        if (department != null)
        {
            return mapper.departmentToDto(department);
        }
        throw new DepartmentNotFoundException("Department with ID " + id + " not found");
    }

    @Override
    public String updateDepartment(int id, DepartmentDTO dto)
    {
        Department department = repository.findById(id).orElse(null);
        if (department != null) 
        {
            department.setDeptName(dto.getDeptName());
            repository.save(department);
            return "Department updated successfully";
        }
        throw new DepartmentNotFoundException("Cannot update. Department not found with ID: " + id);
    }

    @Override
    public List<Employee> getEmployeesByDeptId(int deptId)
    {
        return employeeRepository.findByDepartmentDeptId(deptId);
    }

    @Override
    public String deleteDepartment(int id) {
        Department department = repository.findById(id)
            .orElseThrow(() -> new DepartmentNotFoundException("Cannot delete. Department not found with ID: " + id));

        // Fetch and deactivate employees associated with the department
        List<Employee> employees = employeeRepository.findByDepartmentDeptId(id);
        for (Employee emp : employees) {
            emp.setStatus("Inactive");
            emp.setDepartment(null); // Optionally unset the department association
            employeeRepository.save(emp);
        }

        repository.delete(department);
        return "Department deleted successfully";
    }


}
