package com.hexaware.easypay.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.*;

import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.hexaware.easypay.dto.DepartmentDTO;
import com.hexaware.easypay.entity.Employee;
import com.hexaware.easypay.repository.DepartmentRepository;
import com.hexaware.easypay.serviceInterface.IDepartmentService;

import org.springframework.security.access.prepost.PreAuthorize;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/departments")
public class DepartmentController {

    @Autowired
    private IDepartmentService service;
    
    @Autowired
    private DepartmentRepository departmentRepo;

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/addDepartment")
    public String addDepartment(@RequestBody DepartmentDTO dto) {
        return service.addDepartment(dto);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/assignManager/{deptId}")
    public String assignManager(@PathVariable int deptId, @RequestParam int managerId) {
        return service.assignManager(deptId, managerId);
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    @GetMapping("/showAllDepartments")
    public List<DepartmentDTO> getAllDepartments() {
        return service.getAllDepartments();
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    @GetMapping("/getDepartment/{id}")
    public DepartmentDTO getDepartmentById(@PathVariable int id) {
        return service.getDepartmentById(id);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/updateDepartment/{id}")
    public String updateDepartment(@PathVariable int id, @RequestBody DepartmentDTO dto) {
        return service.updateDepartment(id, dto);
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    @GetMapping("/getEmpByDept/{id}")
    public MappingJacksonValue getEmployeesByDeptId(@PathVariable int id) {
        List<Employee> emp = service.getEmployeesByDeptId(id);
        SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.serializeAllExcept("department", "user");
        FilterProvider filters = new SimpleFilterProvider().addFilter("EmployeeFilter", filter);
        MappingJacksonValue mapping = new MappingJacksonValue(emp);
        mapping.setFilters(filters);
        return mapping;
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/removeDepartment/{id}")
    public String deleteDepartment(@PathVariable int id) {
        return service.deleteDepartment(id);
    }
    
    @GetMapping("/count")
    public long getDepartmentCount() {
        return departmentRepo.count();
    }
    
    
}