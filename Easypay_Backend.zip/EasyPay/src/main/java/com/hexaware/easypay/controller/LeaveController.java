package com.hexaware.easypay.controller;

import com.hexaware.easypay.dto.LeaveDTO;
import com.hexaware.easypay.serviceInterface.ILeaveService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/leave")
public class LeaveController {

    @Autowired
    private ILeaveService service;

    @PostMapping("/requestLeave")
    @PreAuthorize("hasRole('EMPLOYEE')")
    public ResponseEntity<String> requestLeave(@RequestBody LeaveDTO dto) {
        String result = service.requestLeave(dto);
        HttpHeaders headers = new HttpHeaders();
        headers.add("header-info", "Leave request submitted");
        return new ResponseEntity<>(result, headers, HttpStatus.CREATED);
    }
    
    @GetMapping("/viewLeavesByDepartment/{deptId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<LeaveDTO>> viewLeavesByDepartment(@PathVariable int deptId) {
        List<LeaveDTO> leaves = service.getLeavesByDepartmentAndActiveEmployees(deptId);
        return new ResponseEntity<>(leaves, HttpStatus.OK);
    }


    @GetMapping("/myLeaves/{empId}")
    @PreAuthorize("hasAnyRole('EMPLOYEE', 'MANAGER', 'ADMIN')")
    public ResponseEntity<List<LeaveDTO>> getMyLeaves(@PathVariable int empId) {
        List<LeaveDTO> leaves = service.getMyLeaves(empId);
        HttpHeaders headers = new HttpHeaders();
        headers.add("header-info", "Retrieved leaves for employee");
        return new ResponseEntity<>(leaves, headers, HttpStatus.OK);
    }

    @GetMapping("/teamLeaves/{managerId}")
    @PreAuthorize("hasAnyRole('MANAGER')")
    public ResponseEntity<List<LeaveDTO>> getTeamLeaves(@PathVariable int managerId) {
        List<LeaveDTO> leaves = service.getTeamLeaves(managerId);
        HttpHeaders headers = new HttpHeaders();
        headers.add("header-info", "Retrieved team leaves");
        return new ResponseEntity<>(leaves, headers, HttpStatus.OK);
    }

    @PutMapping("/approveLeave/{leaveId}")
    @PreAuthorize("hasAnyRole('MANAGER')")
    public ResponseEntity<String> approveLeave(@PathVariable int leaveId) {
        String result = service.approveLeave(leaveId);
        HttpHeaders headers = new HttpHeaders();
        headers.add("header-info", "Leave approval processed");
        return new ResponseEntity<>(result, headers, HttpStatus.OK);
    }

    @PutMapping("/rejectLeave/{leaveId}")
    @PreAuthorize("hasAnyRole('MANAGER')")
    public ResponseEntity<String> rejectLeave(@PathVariable int leaveId) {
        String result = service.rejectLeave(leaveId);
        HttpHeaders headers = new HttpHeaders();
        headers.add("header-info", "Leave rejection processed");
        return new ResponseEntity<>(result, headers, HttpStatus.OK);
    }
}
