package com.hexaware.easypay.enumeration;

public enum LeaveStatus 
{
    PENDING,
    APPROVED,
    REJECTED
}