package com.hexaware.easypay.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hexaware.easypay.dto.DepartmentDTO;
import com.hexaware.easypay.entity.Department;

@Component
public class DepartmentMapper {

    @Autowired
    private ModelMapper modelMapper;

    public Department dtoToDepartment(DepartmentDTO dto) {
        return modelMapper.map(dto, Department.class);
    }

    public DepartmentDTO departmentToDto(Department department) {
        return modelMapper.map(department, DepartmentDTO.class);
    }
}
