package com.hexaware.easypay.entity;

import com.hexaware.easypay.enumeration.LeaveStatus;
import com.hexaware.easypay.enumeration.LeaveType;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Leaves {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int leaveId;

    @Enumerated(EnumType.STRING)
    @NotNull(message = "Leave type is mandatory")
    private LeaveType leaveType;

    @NotBlank(message = "Start date is mandatory")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "Start date must be in YYYY-MM-DD format")
    private String startDate;

    @NotBlank(message = "End date is mandatory")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "End date must be in YYYY-MM-DD format")
    private String endDate;

    @Enumerated(EnumType.STRING)
     private LeaveStatus status = LeaveStatus.PENDING;

    @ManyToOne
    @JoinColumn(name = "emp_id")
    @NotNull(message = "Employee is mandatory")
    private Employee employee;

    public Leaves() {
    }

    public Leaves(int leaveId, LeaveType leaveType, String startDate, String endDate, 
                 LeaveStatus status, Employee employee) {
        this.leaveId = leaveId;
        this.leaveType = leaveType;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.employee = employee;
    }

    // Getters and setters
    public int getLeaveId() {
        return leaveId;
    }

    public void setLeaveId(int leaveId) {
        this.leaveId = leaveId;
    }

    public LeaveType getLeaveType() {
        return leaveType;
    }

    public void setLeaveType(LeaveType leaveType) {
        this.leaveType = leaveType;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public LeaveStatus getStatus() {
        return status;
    }

    public void setStatus(LeaveStatus status) {
        this.status = status;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    @Override
    public String toString() {
        return "Leaves [leaveId=" + leaveId + ", leaveType=" + leaveType + 
               ", startDate=" + startDate + ", endDate=" + endDate + 
               ", status=" + status + ", employee=" + employee + "]";
    }
}