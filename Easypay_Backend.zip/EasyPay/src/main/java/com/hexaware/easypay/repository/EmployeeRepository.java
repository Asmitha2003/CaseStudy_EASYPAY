package com.hexaware.easypay.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.easypay.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
    List<Employee> findByDepartmentDeptId(int deptId);
    Optional<Employee> findByUser_Id(int userId);  // ✅ FIXED
    Optional<Employee> findByEmpName(String empName);
    List<Employee> findByDepartmentDeptIdAndStatus(int deptId, String status);

}
