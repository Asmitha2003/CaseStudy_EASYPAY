import React, { useEffect, useState } from "react";
import axios from "axios";
import Navbar from "../components/Navbar";
import EmployeeSidebar from "./EmployeeSidebar";

const ShowPayroll = () => {
  const [payData, setPayData] = useState([]);
  const [profileData, setProfileData] = useState(null);

  useEffect(() => {
    const fetchProfile = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        alert("User is not authenticated.");
        return;
      }
      try {
        const res = await axios.get("http://localhost:9000/employee/viewProfile", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setProfileData(res.data);
      } catch (err) {
        alert("Unable to fetch profile. Please try again.");
      }
    };

    fetchProfile();
  }, []);

  useEffect(() => {
    const fetchPayroll = async () => {
      if (!profileData?.empId) return;
      const token = localStorage.getItem("token");
      try {
        const response = await axios.get(
          `http://localhost:9000/payroll/employeePayroll/${profileData.empId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        setPayData(response.data);
      } catch (error) {
        console.error("Error fetching Payrolls:", error.response || error.message);
      }
    };

    if (profileData?.empId) {
      fetchPayroll();
    }
  }, [profileData]);

  return (
    <div className="flex flex-col h-screen">
    <div className="pt-20">
      <Navbar user={true} />
      </div>

      <div className="flex flex-1 overflow-hidden">
        <EmployeeSidebar />

        <div className="flex-1 overflow-y-auto bg-gray-100 p-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-6">Payroll Summary</h1>

          {payData.length === 0 ? (
            <div className="text-center text-gray-500 mt-20 text-lg italic">
              No payroll records found.
            </div>
          ) : (
            <div className="overflow-x-auto bg-white rounded-xl shadow p-4">
              <table className="min-w-full text-sm text-left">
                <thead>
                  <tr className="bg-indigo-100 text-gray-700 uppercase text-xs tracking-wider">
                    <th className="py-3 px-4">S.No</th>
                    <th className="py-3 px-4">Month</th>
                    <th className="py-3 px-4">Basic</th>
                    <th className="py-3 px-4">Allowance</th>
                    <th className="py-3 px-4">Bonus</th>
                    <th className="py-3 px-4">Deduction</th>
                    <th className="py-3 px-4">Net Salary</th>
                  </tr>
                </thead>
                <tbody className="bg-white">
                  {payData.map((entry, index) => (
                    <tr key={index} className="border-b hover:bg-gray-50 transition">
                      <td className="py-3 px-4">{index + 1}</td>
                      <td className="py-3 px-4">
                        {new Date(entry.payDate).toLocaleDateString("en-IN", {
                          month: "short",
                          year: "numeric",
                        })}
                      </td>
                      <td className="py-3 px-4">₹{entry.basicSalary}</td>
                      <td className="py-3 px-4">₹{entry.allowances}</td>
                      <td className="py-3 px-4">₹{entry.bonuses}</td>
                      <td className="py-3 px-4">₹{entry.deductions}</td>
                      <td className="py-3 px-4 font-semibold text-green-600">
                        ₹{entry.netSalary}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ShowPayroll;
