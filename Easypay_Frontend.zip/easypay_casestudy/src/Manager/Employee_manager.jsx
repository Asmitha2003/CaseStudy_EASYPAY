import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import ManagerSidebar from './ManagerSidebar';

const EmployeeManager = () => {
  const [employees, setEmployees] = useState([]);
  const [statusFilter, setStatusFilter] = useState('Active');
  const [loading, setLoading] = useState(true);
  const [selectedLeaves, setSelectedLeaves] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const token = localStorage.getItem('token');

  const parseJwt = (token) => {
    try {
      return JSON.parse(atob(token.split('.')[1]));
    } catch {
      return null;
    }
  };

  const getManagerDepartmentId = async (username) => {
    try {
      const res = await axios.get('http://localhost:9000/departments/showAllDepartments', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const dept = res.data.find((d) => d.managerName === username);
      return dept?.deptId || null;
    } catch (err) {
      console.error('Error fetching departments:', err);
      return null;
    }
  };

  const fetchEmployees = async (deptId, status) => {
    try {
      const res = await axios.get(
        `http://localhost:9000/employee/getEmpByDeptAndStatus/${deptId}/${status}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const filtered = res.data.filter((emp) => emp.designation.toLowerCase() !== 'manager');
      setEmployees(filtered);
    } catch (err) {
      console.error('Error fetching employees:', err);
    } finally {
      setLoading(false);
    }
  };

  const viewLeaves = async (emp) => {
    try {
      const res = await axios.get(`http://localhost:9000/leave/myLeaves/${emp.empId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSelectedLeaves(res.data);
      setSelectedEmployee(emp);
      setShowModal(true);
    } catch (err) {
      console.error('Error fetching leaves:', err);
    }
  };

  useEffect(() => {
    const user = parseJwt(token)?.sub;
    if (user) {
      getManagerDepartmentId(user).then((deptId) => {
        if (deptId) fetchEmployees(deptId, statusFilter);
        else setLoading(false);
      });
    } else {
      console.error('Invalid token');
      setLoading(false);
    }
  }, [statusFilter]);

  const statusBadge = (status) => {
    const base = 'px-2 py-1 rounded-full text-xs font-semibold';
    if (status === 'APPROVED') return <span className={`${base} bg-green-100 text-green-700`}>Approved</span>;
    if (status === 'PENDING') return <span className={`${base} bg-yellow-100 text-yellow-700`}>Pending</span>;
    return <span className={`${base} bg-red-100 text-red-700`}>Rejected</span>;
  };

  return (
    <div className="min-h-screen flex flex-col">
      <div className="fixed top-0 left-0 right-0 z-50">
        <Navbar user={true} />
      </div>

      <div className="flex pt-20">
      <div className="w-64 fixed left-0 top-20 bottom-0 bg-white shadow-md z-40">
        <ManagerSidebar />
      </div>

      {/* Scrollable Content Area */}
      <div className="ml-64 pt-20 h-[calc(100vh-5rem)] overflow-y-auto bg-gray-100 p-8">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex justify-between items-center mb-6 border-b pb-4">
            <h2 className="text-2xl font-bold text-gray-800">Department Employees</h2>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="border border-gray-300 rounded px-3 py-2 text-sm shadow-sm"
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>

          {loading ? (
            <div className="text-center text-gray-500 py-6">Loading employees...</div>
          ) : employees.length === 0 ? (
            <div className="text-center text-red-500 py-6">No employees found.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm text-gray-700 border">
                <thead className="bg-gray-100 text-gray-600 uppercase text-xs tracking-wider">
                  <tr>
                    <th className="px-4 py-3 text-left">ID</th>
                    <th className="px-4 py-3 text-left">Name</th>
                    <th className="px-4 py-3 text-left">Email</th>
                    <th className="px-4 py-3 text-left">Phone</th>
                    <th className="px-4 py-3 text-left">Designation</th>
                    <th className="px-4 py-3 text-left">Address</th>
                    <th className="px-4 py-3 text-left">Salary</th>
                    {statusFilter === 'Active' && (
                      <th className="px-4 py-3 text-left">Actions</th>
                    )}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {employees.map((emp) => (
                    <tr key={emp.empId} className="hover:bg-gray-50">
                      <td className="px-4 py-2 font-mono">{emp.empId}</td>
                      <td className="px-4 py-2">{emp.empName}</td>
                      <td className="px-4 py-2">{emp.email}</td>
                      <td className="px-4 py-2">{emp.phone}</td>
                      <td className="px-4 py-2">{emp.designation}</td>
                      <td className="px-4 py-2">{emp.address}</td>
                      <td className="px-4 py-2">₹{emp.salary}</td>
                      {statusFilter === 'Active' && (
                        <td className="px-4 py-2">
                          <button
  onClick={() => viewLeaves(emp)}
  className="bg-black hover:bg-gray-800 text-white px-3 py-1 rounded shadow-sm"
>
  View Leaves
</button>

                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        </div>

        {/* Leave Modal */}
        {showModal && (
          <div className="fixed inset-0 z-50 bg-black bg-opacity-40 flex items-center justify-center px-4">
            <div className="bg-white w-full max-w-3xl p-6 rounded-xl shadow-lg relative">
              <h3 className="text-xl font-semibold text-gray-800 mb-4 border-b pb-2">
                Leave Records – {selectedEmployee?.empName}
              </h3>
              {selectedLeaves.length === 0 ? (
                <p className="text-gray-500">No leave records available.</p>
              ) : (
                <div className="overflow-auto max-h-[400px]">
                  <table className="w-full text-sm text-gray-700 border">
                    <thead className="bg-gray-100 border-b text-gray-600">
                      <tr>
                        <th className="px-4 py-2 text-left">Leave ID</th>
                        <th className="px-4 py-2 text-left">Start Date</th>
                        <th className="px-4 py-2 text-left">End Date</th>
                        <th className="px-4 py-2 text-left">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {selectedLeaves.map((leave) => (
                        <tr key={leave.leaveId}>
                          <td className="px-4 py-2 font-mono">{leave.leaveId}</td>
                          <td className="px-4 py-2">{leave.startDate}</td>
                          <td className="px-4 py-2">{leave.endDate}</td>
                          <td className="px-4 py-2">{statusBadge(leave.status)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              <div className="mt-6 text-right">
                <button
                  onClick={() => setShowModal(false)}
                  className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>

  );
};

export default EmployeeManager;
