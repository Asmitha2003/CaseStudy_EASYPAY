import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Navbar from '../components/Navbar';
import ManagerSidebar from './ManagerSidebar';
import { fetchManagerStats } from '../redux/managerStatsSlice';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import {
  UserGroupIcon,
  ClipboardDocumentCheckIcon,
  ChartBarIcon,
  LightBulbIcon,
} from '@heroicons/react/24/outline';

const ManagerDashboard = () => {
  const dispatch = useDispatch();
  const { totalEmployees, leaveStats, loading, error } = useSelector(
    (state) => state.managerStats
  );

  useEffect(() => {
    dispatch(fetchManagerStats());
  }, [dispatch]);

  const totalLeaves = leaveStats.reduce((sum, emp) => sum + emp.leaveCount, 0);
  const avgLeaves = (totalLeaves / (totalEmployees || 1)).toFixed(1);

  const monthlyTrend = Array.from({ length: 12 }, (_, i) => ({
    month: new Date(0, i).toLocaleString('default', { month: 'short' }),
    leaves: 0,
  }));

  let hasLeaveDates = false;

  leaveStats.forEach((emp) => {
    if (emp.leaveDates && Array.isArray(emp.leaveDates)) {
      hasLeaveDates = true;
      emp.leaveDates.forEach((dateStr) => {
        const date = new Date(dateStr);
        const monthIndex = date.getMonth();
        if (!isNaN(monthIndex)) {
          monthlyTrend[monthIndex].leaves += 1;
        }
      });
    }
  });

  return (
    <div className="flex flex-col h-screen">
    <div className="pt-20">
      <Navbar user={true} />
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <div className="h-full">
          <ManagerSidebar />
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto bg-gray-50 p-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-8">Manager Dashboard</h1>

          {loading ? (
            <p className="text-gray-600">Loading...</p>
          ) : error ? (
            <p className="text-red-500">Error: {error}</p>
          ) : (
            <>
              {/* Stat Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                <StatCard
                  title="Employees"
                  value={totalEmployees}
                  icon={<UserGroupIcon className="w-6 h-6 text-blue-500" />}
                  color="bg-blue-100"
                />
                <StatCard
                  title="Total Leave Requests"
                  value={totalLeaves}
                  icon={<ClipboardDocumentCheckIcon className="w-6 h-6 text-emerald-500" />}
                  color="bg-emerald-100"
                />
                <StatCard
                  title="Avg Leaves per Employee"
                  value={avgLeaves}
                  icon={<ChartBarIcon className="w-6 h-6 text-purple-500" />}
                  color="bg-purple-100"
                />
              </div>

              {/* Chart */}
              <div className="bg-white p-6 rounded-2xl shadow mb-12">
                <h2 className="text-xl font-semibold text-gray-800 mb-4">Monthly Leave Trend</h2>
                {hasLeaveDates ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart
                      data={monthlyTrend}
                      margin={{ top: 20, right: 30, left: 0, bottom: 10 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="leaves" fill="#4b5563" radius={[6, 6, 0, 0]} barSize={40} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="text-gray-500 text-sm italic">
                    Monthly leave data will appear once leave dates are recorded.
                  </div>
                )}
              </div>

              {/* Guidelines */}
              <div className="bg-white p-6 rounded-2xl shadow">
                <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                  <LightBulbIcon className="w-5 h-5 mr-2 text-yellow-500" />
                  Manager Guidelines
                </h2>
                <ul className="list-disc text-gray-700 text-sm pl-6 space-y-2">
                  <li>Monitor peak leave months to better manage workload.</li>
                  <li>Identify consistent patterns for proactive planning.</li>
                  <li>Encourage early leave requests to reduce conflicts.</li>
                </ul>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, icon, color }) => (
  <div
    className={`rounded-2xl shadow-sm p-5 flex items-center justify-between hover:shadow-md transition ${color}`}
  >
    <div>
      <p className="text-sm text-gray-600">{title}</p>
      <p className="text-3xl font-semibold text-gray-800 mt-1">{value}</p>
    </div>
    <div className="p-3 rounded-full bg-white shadow-inner">{icon}</div>
  </div>
);

export default ManagerDashboard;
