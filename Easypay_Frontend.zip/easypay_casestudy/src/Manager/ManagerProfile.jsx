import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';

const ManagerProfile = () => {
  const token = localStorage.getItem('token');
  const [managerData, setManagerData] = useState(null);
  const [editableData, setEditableData] = useState({});
  const [editMode, setEditMode] = useState(false);
  const [loading, setLoading] = useState(true);
  const [successMsg, setSuccessMsg] = useState('');

  const getManager = async () => {
    try {
      const response = await axios.get('http://localhost:9000/employee/viewProfile', {
        headers: { Authorization: `Bearer ${token}` },
      });

      const manager = response.data;
      setManagerData(manager);
      setEditableData({
        email: manager.email,
        phone: manager.phone,
        address: manager.address,
        gender: manager.gender,
      });
    } catch (error) {
      console.error('Error fetching manager profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async () => {
    try {
      await axios.put(
        `http://localhost:9000/employee/updateOwnProfile/${managerData.empId}`,
        editableData,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setManagerData({ ...managerData, ...editableData });
      setSuccessMsg('✅ Profile updated successfully!');
      setEditMode(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  useEffect(() => {
    getManager();
  }, []);

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toISOString().split('T')[0]; 
  };

  return (
    <>
    <div className="pt-20">
      <Navbar />
      </div>
      <div className="p-6 bg-gradient-to-br from-gray-50 to-blue-50 min-h-screen flex justify-center">
        <div className="bg-white shadow-2xl rounded-xl w-full max-w-3xl p-8">
          <h2 className="text-3xl font-bold text-blue-800 text-center mb-8">My Profile</h2>

          {loading ? (
            <div className="text-center text-gray-500">Loading...</div>
          ) : !managerData ? (
            <div className="text-center text-red-500">Profile not found.</div>
          ) : (
            <>
              {successMsg && (
                <div className="bg-green-100 text-green-800 border border-green-300 px-4 py-2 rounded mb-4 text-center">
                  {successMsg}
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
                <div>
                  <label className="block text-sm font-semibold text-gray-600">Name</label>
                  <p className="mt-1 p-2 bg-gray-100 rounded">{managerData.empName}</p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-600">Designation</label>
                  <p className="mt-1 p-2 bg-gray-100 rounded">{managerData.designation}</p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-600">Department</label>
                  <p className="mt-1 p-2 bg-gray-100 rounded">{managerData.deptName}</p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-600">Salary</label>
                  <p className="mt-1 p-2 bg-gray-100 rounded">₹{managerData.salary}</p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-600">Joining Date</label>
                  <p className="mt-1 p-2 bg-gray-100 rounded">{formatDate(managerData.joiningDate)}</p>
                </div>

                <div>
  <label className="block text-sm font-semibold text-gray-600">Status</label>
  <p className="mt-1 p-2 bg-gray-100 rounded">{managerData.status}</p>
</div>

                <div>
                  <label className="block text-sm font-semibold text-gray-600">Email</label>
                  {editMode ? (
                    <input
                      type="email"
                      value={editableData.email}
                      onChange={(e) => setEditableData({ ...editableData, email: e.target.value })}
                      className="w-full mt-1 border px-3 py-2 rounded shadow-sm"
                    />
                  ) : (
                    <p className="mt-1 p-2 bg-gray-100 rounded">{managerData.email}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-600">Phone</label>
                  {editMode ? (
                    <input
                      type="text"
                      value={editableData.phone}
                      onChange={(e) => setEditableData({ ...editableData, phone: e.target.value })}
                      className="w-full mt-1 border px-3 py-2 rounded shadow-sm"
                    />
                  ) : (
                    <p className="mt-1 p-2 bg-gray-100 rounded">{managerData.phone}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-600">Gender</label>
                  {editMode ? (
                    <select
                      value={editableData.gender || ''}
                      onChange={(e) => setEditableData({ ...editableData, gender: e.target.value })}
                      className="w-full mt-1 border px-3 py-2 rounded shadow-sm"
                    >
                      <option value="">-- Select Gender --</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  ) : (
                    <p className="mt-1 p-2 bg-gray-100 rounded">{managerData.gender}</p>
                  )}
                </div>


                <div className="md:col-span-2">
                  <label className="block text-sm font-semibold text-gray-600">Address</label>
                  {editMode ? (
                    <textarea
                      rows="3"
                      value={editableData.address}
                      onChange={(e) => setEditableData({ ...editableData, address: e.target.value })}
                      className="w-full mt-1 border px-3 py-2 rounded shadow-sm"
                    />
                  ) : (
                    <p className="mt-1 p-2 bg-gray-100 rounded">{managerData.address}</p>
                  )}
                </div>
              </div>

              {/* Buttons */}
              <div className="mt-6 flex justify-center gap-4">
                {editMode ? (
                  <>
                    <button
                      onClick={handleUpdate}
                      className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => {
                        setEditMode(false);
                        setEditableData({
                          email: managerData.email,
                          phone: managerData.phone,
                          address: managerData.address,
                          gender: managerData.gender,
                          status: managerData.status,
                        });
                      }}
                      className="bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg"
                    >
                      Cancel
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => setEditMode(true)}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg"
                  >
                    Edit Info
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default ManagerProfile;
