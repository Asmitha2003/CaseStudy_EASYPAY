import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import ManagerSidebar from './ManagerSidebar';

const LeaveManager = () => {
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const token = localStorage.getItem('token');

  const parseJwt = (token) => {
    try {
      return JSON.parse(atob(token.split('.')[1]));
    } catch {
      return null;
    }
  };

  const fetchLeaves = async (managerEmpId) => {
    try {
      const response = await axios.get(`http://localhost:9000/leave/teamLeaves/${managerEmpId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setLeaves(response.data);
    } catch (error) {
      console.error('Error fetching leave requests:', error);
    } finally {
      setLoading(false);
    }
  };

  const getManagerEmpId = async () => {
    const username = parseJwt(token)?.sub;
    if (!username) return setLoading(false);

    try {
      const res = await axios.get('http://localhost:9000/employee/viewAllEmployees', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const emp = res.data.find(e => e.empName.toLowerCase() === username.toLowerCase());
      if (emp) fetchLeaves(emp.empId);
    } catch (err) {
      console.error('Error fetching manager ID:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAction = async (leaveId, action) => {
    const confirmAction = window.confirm(`Are you sure you want to ${action} this leave request?`);
    if (!confirmAction) return;

    try {
      await axios.put(`http://localhost:9000/leave/${action}Leave/${leaveId}`, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setLeaves(prev =>
        prev.map(l =>
          l.leaveId === leaveId ? { ...l, status: action === 'approve' ? 'APPROVED' : 'REJECTED' } : l
        )
      );
    } catch (err) {
      console.error(`Error on ${action}:`, err);
    }
  };

  useEffect(() => {
    getManagerEmpId();
  }, []);

  const statusBadge = (status) => {
    const base = "px-2 py-1 text-xs rounded-full font-semibold";
    if (status === 'PENDING') return <span className={`${base} bg-yellow-100 text-yellow-800`}>Pending</span>;
    if (status === 'APPROVED') return <span className={`${base} bg-green-100 text-green-800`}>Approved</span>;
    return <span className={`${base} bg-red-100 text-red-800`}>Rejected</span>;
  };

  const filteredData = (data) => {
    const q = searchQuery.toLowerCase();
    return data.filter(
      l =>
        l.employee?.empName?.toLowerCase().includes(q) ||
        l.startDate.includes(q)
    );
  };

  const renderTable = (title, data, showActions = false) => (
    <div className="mb-10 bg-white rounded-xl shadow p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">{title}</h3>
      <div className="overflow-x-auto">
        <table className="min-w-full text-sm text-left border">
          <thead className="bg-teal-600 text-white text-xs uppercase tracking-wider">
            <tr>
              <th className="px-5 py-3">Leave ID</th>
              <th className="px-5 py-3">Employee Name</th>
              <th className="px-5 py-3">Start Date</th>
              <th className="px-5 py-3">End Date</th>
              <th className="px-5 py-3">Status</th>
              {showActions && <th className="px-5 py-3">Actions</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filteredData(data).length === 0 ? (
              <tr>
                <td colSpan={showActions ? 6 : 5} className="text-center py-6 text-gray-400">
                  No matching records
                </td>
              </tr>
            ) : (
              filteredData(data).map((leave) => (
                <tr key={leave.leaveId} className="hover:bg-gray-50 transition duration-150">
                  <td className="px-5 py-3 font-mono">{leave.leaveId}</td>
                  <td className="px-5 py-3">{leave.employee?.empName}</td>
                  <td className="px-5 py-3">{leave.startDate}</td>
                  <td className="px-5 py-3">{leave.endDate}</td>
                  <td className="px-5 py-3">{statusBadge(leave.status)}</td>
                  {showActions && (
                    <td className="px-5 py-3 flex gap-2">
                      <button
                        onClick={() => handleAction(leave.leaveId, 'approve')}
                        className="bg-green-600 hover:bg-green-700 text-white text-xs px-3 py-1 rounded-md"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => handleAction(leave.leaveId, 'reject')}
                        className="bg-red-600 hover:bg-red-700 text-white text-xs px-3 py-1 rounded-md"
                      >
                        Reject
                      </button>
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  const pending = leaves.filter(l => l.status === 'PENDING');
  const approved = leaves.filter(l => l.status === 'APPROVED');
  const rejected = leaves.filter(l => l.status === 'REJECTED');

  return (
    <div className="min-h-screen flex flex-col">
      <div className="fixed top-0 left-0 right-0 z-50">
        <Navbar user={true} />
      </div>
      <div className="flex pt-20">
        <div className="w-64 fixed left-0 top-20 bottom-0 bg-white shadow-md z-40">
          <ManagerSidebar />
        </div>
        <div className="flex-1 ml-64 bg-gray-50 p-8 overflow-y-auto">
          <div className="mb-10 text-center">
            <h2 className="text-3xl font-bold text-gray-900">Manage Leave Requests</h2>
            <p className="text-gray-500 mt-1 text-sm">
              Review and respond to your team's leave applications.
            </p>
          </div>

          <div className="mb-6 flex justify-end">
            <input
              type="text"
              placeholder="Search by employee or date..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="border border-gray-300 rounded px-4 py-2 shadow-sm w-80"
            />
          </div>

          {loading ? (
            <div className="text-center text-gray-500 py-10">Loading leave requests...</div>
          ) : (
            <>
              {renderTable('Pending Leave Requests', pending, true)}
              {renderTable('Approved Leave Requests', approved)}
              {renderTable('Rejected Leave Requests', rejected)}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default LeaveManager;
