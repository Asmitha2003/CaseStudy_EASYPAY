import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import AdminSidebar from './AdminSidebar';
import { CheckCircleIcon, ClockIcon, XCircleIcon } from '@heroicons/react/24/solid';

const LeaveManagement = () => {
  const [departments, setDepartments] = useState([]);
  const [selectedDeptId, setSelectedDeptId] = useState('');
  const [leaves, setLeaves] = useState([]);
  const token = localStorage.getItem('token');

  const fetchDepartments = async () => {
    const res = await axios.get('http://localhost:9000/departments/showAllDepartments', {
      headers: { Authorization: `Bearer ${token}` },
    });
    setDepartments(res.data);
    if (res.data.length > 0) {
      setSelectedDeptId(res.data[0].deptId);
    }
  };

  const fetchLeavesByDept = async (deptId) => {
    const res = await axios.get(`http://localhost:9000/leave/viewLeavesByDepartment/${deptId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    setLeaves(res.data);
  };

  useEffect(() => {
    fetchDepartments();
  }, []);

  useEffect(() => {
    if (selectedDeptId) fetchLeavesByDept(selectedDeptId);
  }, [selectedDeptId]);

  const renderStatusBadge = (status) => {
    let icon, bg, text;

    if (status === 'APPROVED') {
      icon = <CheckCircleIcon className="w-4 h-4 mr-1" />;
      bg = 'bg-green-100 text-green-700';
      text = 'Approved';
    } else if (status === 'PENDING') {
      icon = <ClockIcon className="w-4 h-4 mr-1" />;
      bg = 'bg-yellow-100 text-yellow-700';
      text = 'Pending';
    } else if (status === 'REJECTED') {
      icon = <XCircleIcon className="w-4 h-4 mr-1" />;
      bg = 'bg-red-100 text-red-700';
      text = 'Rejected';
    } else {
      icon = null;
      bg = 'bg-gray-100 text-gray-600';
      text = status;
    }

    return (
      <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full ${bg}`}>
        {icon}
        {text}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="fixed top-0 left-0 w-full z-50">
        <Navbar user={true} />
      </div>

      <div className="flex pt-20">
        <div className="fixed top-16 left-0 h-full w-64 bg-white border-r z-40">
          <AdminSidebar />
        </div>

        <main className="ml-64 w-full px-6 py-8 bg-gray-50 min-h-screen overflow-y-auto">
          <div className="bg-white shadow-md rounded-lg p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Leave Management</h2>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Filter by Department
              </label>
              <select
                value={selectedDeptId}
                onChange={(e) => setSelectedDeptId(e.target.value)}
                className="w-full max-w-md border border-gray-300 rounded-md shadow-sm px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {departments.map((dept) => (
                  <option key={dept.deptId} value={dept.deptId}>
                    {dept.deptName}
                  </option>
                ))}
              </select>
            </div>

            {leaves.length === 0 ? (
              <p className="text-gray-600 text-sm italic">
                No leave records found for this department.
              </p>
            ) : (
              <div className="overflow-x-auto rounded-md border border-gray-200">
                <table className="min-w-full text-sm divide-y divide-gray-200">
                  <thead className="bg-gray-100 text-gray-700">
                    <tr>
                      <th className="py-3 px-4 text-left font-medium">Leave ID</th>
                      <th className="py-3 px-4 text-left font-medium">Employee ID</th>
                      <th className="py-3 px-4 text-left font-medium">From</th>
                      <th className="py-3 px-4 text-left font-medium">To</th>
                      <th className="py-3 px-4 text-left font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-100">
                    {leaves.map((leave) => (
                      <tr key={leave.leaveId} className="hover:bg-gray-50">
                        <td className="px-4 py-3 text-gray-800">{leave.leaveId}</td>
                        <td className="px-4 py-3 text-gray-700">{leave.empId}</td>
                        <td className="px-4 py-3 text-gray-700">{leave.startDate}</td>
                        <td className="px-4 py-3 text-gray-700">{leave.endDate}</td>
                        <td className="px-4 py-3">{renderStatusBadge(leave.status)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default LeaveManagement;
