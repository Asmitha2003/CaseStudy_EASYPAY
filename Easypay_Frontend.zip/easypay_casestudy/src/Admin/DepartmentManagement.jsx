import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import AdminSidebar from './AdminSidebar';

const DepartmentManagement = () => {
  const [departments, setDepartments] = useState([]);
  const [newDeptName, setNewDeptName] = useState('');
  const [editingDept, setEditingDept] = useState(null);
  const [editDeptName, setEditDeptName] = useState('');

  const token = localStorage.getItem('token');

  const fetchDepartments = async () => {
    try {
      const res = await axios.get('http://localhost:9000/departments/showAllDepartments', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setDepartments(res.data);
    } catch (err) {
      console.error('Error fetching departments:', err);
    }
  };

  const addDepartment = async () => {
    if (!newDeptName.trim()) return alert("Department name cannot be empty");
    try {
      await axios.post(
        'http://localhost:9000/departments/addDepartment',
        { deptName: newDeptName },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setNewDeptName('');
      fetchDepartments();
    } catch (err) {
      console.error('Error adding department:', err);
    }
  };

  const startEdit = (dept) => {
    setEditingDept(dept);
    setEditDeptName(dept.deptName);
  };

  const updateDepartment = async () => {
    try {
      await axios.put(
        `http://localhost:9000/departments/updateDepartment/${editingDept.deptId}`,
        { deptName: editDeptName },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setEditingDept(null);
      fetchDepartments();
    } catch (err) {
      console.error('Error updating department:', err);
    }
  };

  const deleteDepartment = async (id) => {
    if (window.confirm('Are you sure you want to delete this department?')) {
      try {
        await axios.delete(`http://localhost:9000/departments/removeDepartment/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        fetchDepartments();
      } catch (err) {
        console.error('Error deleting department:', err);
      }
    }
  };

  useEffect(() => {
    fetchDepartments();
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <div className="fixed top-0 left-0 w-full z-50">
        <Navbar user={true} />
      </div>

      <div className="flex pt-20">
        <div className="fixed top-20 left-0 h-full w-64 bg-white border-r z-40">
          <AdminSidebar />
        </div>

        <main className="ml-64 w-full px-6 py-8 bg-gray-50 min-h-screen overflow-y-auto">
          <div className="bg-white shadow-md rounded-lg p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Department Management</h2>

            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-6">
              <input
                type="text"
                value={newDeptName}
                onChange={(e) => setNewDeptName(e.target.value)}
                placeholder="Enter department name"
                className="px-4 py-2 border border-gray-300 rounded-md w-full sm:w-1/2"
              />
              <button
                onClick={addDepartment}
                className="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded-md"
              >
                + Add Department
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full text-sm border border-gray-200 rounded-md">
                <thead className="bg-gray-100 text-gray-700">
                  <tr>
                    <th className="py-3 px-4 text-left">ID</th>
                    <th className="py-3 px-4 text-left">Department Name</th>
                    <th className="py-3 px-4 text-left">Manager</th>
                    <th className="py-3 px-4 text-left">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white">
                  {departments.map((dept, idx) => (
                    <tr key={dept.deptId} className={idx % 2 === 0 ? '' : 'bg-gray-50'}>
                      <td className="px-4 py-3">{dept.deptId}</td>
                      <td className="px-4 py-3">{dept.deptName}</td>
                      <td className="px-4 py-3">
                        {dept.managerName ? dept.managerName : <span className="text-gray-400">Not Assigned</span>}
                      </td>
                      <td className="px-4 py-3 space-x-2">
                        <button
                          onClick={() => startEdit(dept)}
                          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-md"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => deleteDepartment(dept.deptId)}
                          className="bg-red-600 hover:bg-red-700 text-white px-4 py-1 rounded-md"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {editingDept && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md mx-4">
                  <h2 className="text-lg font-bold text-gray-800 mb-4">Edit Department</h2>
                  <input
                    type="text"
                    value={editDeptName}
                    onChange={(e) => setEditDeptName(e.target.value)}
                    className="w-full border border-gray-300 px-4 py-2 rounded mb-4"
                  />
                  <div className="flex justify-end gap-4">
                    <button
                      onClick={() => setEditingDept(null)}
                      className="bg-gray-400 hover:bg-gray-500 text-white px-4 py-2 rounded-md"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={updateDepartment}
                      className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md"
                    >
                      Save Changes
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default DepartmentManagement;
