import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import AdminSidebar from './AdminSidebar';

const PayrollManagement = () => {
  const [payrolls, setPayrolls] = useState([]);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({
    basicSalary: 0,
    bonuses: 0,
    allowances: 0,
    deductions: 0,
    payDate: '',
    empId: ''
  });
  const [newMode, setNewMode] = useState(false);
  const [filteredPayrolls, setFilteredPayrolls] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState('');
  const [selectedYear, setSelectedYear] = useState('');
  const token = localStorage.getItem('token');

  const fetchAll = async () => {
    try {
      const res = await axios.get('http://localhost:9000/payroll/viewAllPayroll', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setPayrolls(res.data);
      setFilteredPayrolls(res.data);
    } catch (err) {
      console.error('Fetch payrolls error:', err);
    }
  };

  const fetchCalculatedPayroll = async (empId, payDate) => {
    try {
      const res = await axios.get(`http://localhost:9000/payroll/calculatePayroll/${empId}?payDate=${payDate}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const { basicSalary, bonuses, allowances, deductions } = res.data;
      setForm((prev) => ({
        ...prev,
        basicSalary,
        bonuses,
        allowances,
        deductions
      }));
    } catch (err) {
      console.error('Error fetching calculated payroll:', err);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    const updatedForm = { ...form, [name]: value };
    setForm(updatedForm);
    if ((name === 'empId' || name === 'payDate') && updatedForm.empId && updatedForm.payDate && newMode) {
      fetchCalculatedPayroll(updatedForm.empId, updatedForm.payDate);
    }
  };

  const openNew = () => {
    setForm({ basicSalary: 0, bonuses: 0, allowances: 0, deductions: 0, payDate: '', empId: '' });
    setNewMode(true);
    setEditing(null);
  };

  const openEdit = (p) => {
    setEditing(p);
    setForm({
      basicSalary: p.basicSalary,
      bonuses: p.bonuses,
      allowances: p.allowances,
      deductions: p.deductions,
      payDate: p.payDate,
      empId: p.empId
    });
    setNewMode(false);
  };

  const submitForm = async () => {
    const url = newMode
      ? 'http://localhost:9000/payroll/addPayroll'
      : `http://localhost:9000/payroll/updatePayroll/${editing.payrollId}`;
    const method = newMode ? axios.post : axios.put;
    try {
      await method(url, form, { headers: { Authorization: `Bearer ${token}` } });
      setNewMode(false);
      setEditing(null);
      fetchAll();
    } catch (err) {
      console.error('Error saving payroll:', err);
    }
  };

  const deletePayroll = async (id) => {
    if (!window.confirm('Are you sure you want to delete this payroll record?')) return;
    try {
      await axios.delete(`http://localhost:9000/payroll/deletePayroll/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchAll();
    } catch (err) {
      console.error('Delete payroll error:', err);
    }
  };

  const filterPayrolls = () => {
    if (!selectedMonth && !selectedYear) {
      setFilteredPayrolls(payrolls);
      return;
    }

    const filtered = payrolls.filter((p) => {
      const date = new Date(p.payDate);
      const matchMonth = selectedMonth ? date.getMonth() + 1 === parseInt(selectedMonth) : true;
      const matchYear = selectedYear ? date.getFullYear() === parseInt(selectedYear) : true;
      return matchMonth && matchYear;
    });

    setFilteredPayrolls(filtered);
  };

  useEffect(() => {
    fetchAll();
  }, []);

  useEffect(() => {
    filterPayrolls();
  }, [selectedMonth, selectedYear, payrolls]);

  return (
    <div className="h-screen flex flex-col">
      <div className="pt-20">
        <Navbar user={true} />
      </div>
      <div className="flex flex-1">
        <AdminSidebar />
        <div className="flex-1 bg-gray-50 p-6 overflow-y-auto">
          <div className="bg-white shadow-md rounded-lg p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Payroll Management</h2>

            <div className="flex flex-wrap items-center gap-4 mb-6">
              <button
                onClick={openNew}
                className="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded-md"
              >
                + Add New Payroll
              </button>

              <select
                className="border p-2 rounded"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
              >
                <option value="">All Months</option>
                {Array.from({ length: 12 }, (_, i) => (
                  <option key={i + 1} value={i + 1}>
                    {new Date(0, i).toLocaleString('default', { month: 'long' })}
                  </option>
                ))}
              </select>

              <select
                className="border p-2 rounded"
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value)}
              >
                <option value="">All Years</option>
                {[...new Set(payrolls.map(p => new Date(p.payDate).getFullYear()))].map(year => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full text-sm border border-gray-200 rounded-md">
                <thead className="bg-gray-100 text-gray-700">
                  <tr>
                    <th className="py-3 px-4 text-left">ID</th>
                    <th className="py-3 px-4 text-left">Employee ID</th>
                    <th className="py-3 px-4 text-left">Pay Date</th>
                    <th className="py-3 px-4 text-left">Net Salary</th>
                    <th className="py-3 px-4 text-left">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white">
                  {filteredPayrolls.map((p, idx) => (
                    <tr key={p.payrollId} className={idx % 2 === 0 ? '' : 'bg-gray-50'}>
                      <td className="px-4 py-3">{p.payrollId}</td>
                      <td className="px-4 py-3">{p.empId}</td>
                      <td className="px-4 py-3">{p.payDate}</td>
                      <td className="px-4 py-3">{p.netSalary}</td>
                      <td className="px-4 py-3 space-x-2">
                        <button
                          onClick={() => openEdit(p)}
                          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-md"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => deletePayroll(p.payrollId)}
                          className="bg-red-600 hover:bg-red-700 text-white px-4 py-1 rounded-md"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {(editing || newMode) && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg mx-4">
                  <h3 className="text-lg font-bold mb-4">
                    {newMode ? 'Add Payroll' : 'Edit Payroll'}
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium">Employee ID</label>
                      <input
                        name="empId"
                        type="number"
                        value={form.empId}
                        onChange={handleChange}
                        className="p-2 border rounded w-full"
                        disabled={!newMode}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium">Pay Date</label>
                      <input
                        name="payDate"
                        type="date"
                        value={form.payDate}
                        onChange={handleChange}
                        className="p-2 border rounded w-full"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium">Basic Salary</label>
                      <input
                        name="basicSalary"
                        type="number"
                        value={form.basicSalary}
                        readOnly
                        className="p-2 border rounded w-full bg-gray-100"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium">Bonuses</label>
                      <input
                        name="bonuses"
                        type="number"
                        value={form.bonuses}
                        readOnly
                        className="p-2 border rounded w-full bg-gray-100"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium">Allowances</label>
                      <input
                        name="allowances"
                        type="number"
                        value={form.allowances}
                        readOnly
                        className="p-2 border rounded w-full bg-gray-100"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium">Deductions</label>
                      <input
                        name="deductions"
                        type="number"
                        value={form.deductions}
                        readOnly
                        className="p-2 border rounded w-full bg-gray-100"
                      />
                    </div>
                  </div>
                  <div className="mt-4 flex justify-end gap-4">
                    <button
                      onClick={() => { setEditing(null); setNewMode(false); }}
                      className="bg-gray-400 hover:bg-gray-500 text-white px-4 py-2 rounded-md"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={submitForm}
                      className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md"
                    >
                      Save
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PayrollManagement;
