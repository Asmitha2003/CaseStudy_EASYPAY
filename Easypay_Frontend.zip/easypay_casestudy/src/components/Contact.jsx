import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeftIcon } from '@heroicons/react/24/solid';
import Navbar from './Navbar';

const Contact = () => {
  return (
    <>
      <Navbar />
      <div className="pt-28 pb-20 px-4 bg-gray-100 min-h-screen">
        <div className="max-w-6xl mx-auto bg-white shadow-lg rounded-xl grid grid-cols-1 md:grid-cols-2 overflow-hidden">
          
          {/* Info Section */}
          <div className="bg-indigo-700 text-white p-10 flex flex-col justify-center">
            <Link to="/" className="mb-4 inline-flex items-center text-sm hover:underline">
              <ArrowLeftIcon className="h-5 w-5 mr-1" />
              Back to Home
            </Link>
            <h2 className="text-4xl font-bold mb-3 leading-snug">Get In Touch</h2>
            <p className="text-indigo-100 mb-6 text-sm leading-relaxed">
              We’re here to help! Reach out with any payroll-related questions, demo requests, or support needs.
            </p>
            <ul className="text-sm space-y-3">
              <li>
                <span className="font-semibold">Address:</span> 123 Payroll Avenue, Tech Park, India
              </li>
              <li>
                <span className="font-semibold">Phone:</span> +91 98765 43210
              </li>
              <li>
                <span className="font-semibold">Email:</span> support@easypay.com
              </li>
              <li>
                <span className="font-semibold">Hours:</span> Mon - Fri, 9AM - 6PM IST
              </li>
            </ul>
          </div>

          {/* Contact Form */}
          <form className="p-10 bg-white">
            <h3 className="text-2xl font-semibold text-gray-800 mb-6">Send Us a Message</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <input
                type="text"
                placeholder="First Name"
                className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-indigo-400"
              />
              <input
                type="text"
                placeholder="Last Name"
                className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-indigo-400"
              />
            </div>

            <div className="mb-4">
              <input
                type="email"
                placeholder="Email Address"
                className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-indigo-400"
              />
            </div>

            <div className="mb-4">
              <input
                type="tel"
                placeholder="Phone Number"
                className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-indigo-400"
              />
            </div>

            <div className="mb-4">
              <textarea
                placeholder="Your Message"
                rows="4"
                className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-indigo-400"
              ></textarea>
            </div>

            <div className="flex items-center mb-6">
              <input type="checkbox" className="mr-2" />
              <label className="text-sm text-gray-600">
                Subscribe to our newsletter
              </label>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 text-white py-3 rounded hover:bg-indigo-700 transition-all font-semibold"
            >
              Send Message
            </button>
          </form>
        </div>
      </div>
    </>
  );
};

export default Contact;
