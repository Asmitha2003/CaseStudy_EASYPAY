import React from 'react';
import Navbar from './Navbar';

const PrivacyPolicy = () => {
  return (
    <>
      <Navbar />
      <div className="min-h-screen bg-gray-50 pt-24 px-4 pb-20">
        <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl p-8">
         <h1 className="text-3xl font-bold text-gray-900 mb-8 text-center">Privacy Policy</h1>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Information We Collect</h2>
            <p className="text-gray-600 leading-relaxed">
              We collect information that you provide directly to us, including when you create an account,
              access payroll services, or contact support. This may include:
            </p>
            <div className="mt-4 space-y-2">
              {[
                "Name and contact information",
                "Employee & payroll-related data",
                "Device and usage information",
              ].map((item, index) => (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 text-blue-500">
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </div>
                  <span className="ml-3 text-gray-600">{item}</span>
                </div>
              ))}
            </div>
          </section>

         
          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">How We Use Your Information</h2>
            <div className="bg-gray-50 rounded-lg p-6">
              <ul className="space-y-4">
                {[
                  "To manage payroll and employee records",
                  "To provide customer support",
                  "To improve our application experience",
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <div className="flex-shrink-0 h-6 w-6 text-blue-500">
                      <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M13 10V3L4 14h7v7l9-11h-7z"
                        />
                      </svg>
                    </div>
                    <span className="ml-3 text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </section>

         
          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Data Security</h2>
            <p className="text-gray-600 mb-4">
              We implement robust technical and organizational security measures to protect your personal information.
              However, no method of transmission over the Internet is 100% secure.
            </p>
            <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
              <p className="text-blue-700">
                We regularly audit and update our infrastructure and processes to enhance your data protection.
              </p>
            </div>
          </section>

        
          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Your Rights</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { title: "Access", desc: "Request access to your personal data." },
                { title: "Rectification", desc: "Request correction of inaccurate data." },
                { title: "Erasure", desc: "Request deletion of your data." },
                { title: "Portability", desc: "Request transfer of your data to another service." },
              ].map((right, index) => (
                <div key={index} className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="font-medium text-gray-900 mb-2">{right.title}</h3>
                  <p className="text-gray-600">{right.desc}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </>
  );
};

export default PrivacyPolicy;
