import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";

const Navbar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const user = localStorage.getItem("token");

  const isActive = (path) =>
    location.pathname === path
      ? "text-indigo-600 font-semibold border-b-2 border-indigo-600"
      : "text-gray-600 hover:text-indigo-600";

  const logout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <nav className="bg-white shadow-sm border-b py-3 px-4 fixed top-0 w-full z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Left Logo */}
        <div className="flex items-center space-x-2">
          <Link to="/">
            <img
              src="https://icon-library.com/images/payroll-icon/payroll-icon-5.jpg"
              alt="Easypay Logo"
              className="w-8 h-8 object-contain"
            />
          </Link>
          <span className="text-lg font-bold text-gray-800">Easypay</span>
        </div>

        {/* Center Nav Links */}
        <ul className="hidden md:flex space-x-6 text-sm">
          <li>
            <Link to="/" className={`${isActive("/")} px-1`}>
              Home
            </Link>
          </li>
          <li>
            <Link to="/about" className={`${isActive("/about")} px-1`}>
              About
            </Link>
          </li>
          <li>
            <Link to="/contact" className={`${isActive("/contact")} px-1`}>
              Contact
            </Link>
          </li>
        </ul>

        {/* Right Auth */}
        <div className="flex items-center space-x-4 text-sm">
          {user ? (
            <button
              onClick={logout}
              className="bg-indigo-500 hover:bg-indigo-700 text-white px-4 py-2 rounded-md font-medium"
            >
              Logout
            </button>
          ) : (
            <>
              <Link
                to="/login"
                className="text-indigo-600 hover:text-indigo-800 font-medium"
              >
                Login
              </Link>
              <Link
                to="/signup"
                className="bg-indigo-500 hover:bg-indigo-700 text-white px-4 py-2 rounded-md font-medium"
              >
                Sign Up
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
