import React from 'react';
import Navbar from './Navbar';

const TermsAndCondition = () => {
  return (
    <>
     <div className="pt-20">
    <Navbar/>
    </div>
    <div className="bg-gray-50 min-h-screen py-16 px-4">
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl p-8">
        <h1 className="text-3xl font-bold text-gray-900 text-center mb-10">Terms of Service</h1>

        {/* Section 1 */}
        <section className="mb-10">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">1. Acceptance of Terms</h2>
          <p className="text-gray-600 leading-relaxed">
            By accessing and using this website, you accept and agree to be bound by the terms and provision of this agreement.
          </p>
        </section>

        {/* Section 2 */}
        <section className="mb-10">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">2. Use License</h2>
          <div className="bg-gray-50 rounded-lg p-6 space-y-4 text-gray-600">
            <div className="flex gap-3 items-start">
              <svg className="h-6 w-6 text-blue-500 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
              <span>Permission is granted to temporarily download one copy of the materials for personal, non-commercial transitory viewing only.</span>
            </div>
            <div className="flex gap-3 items-start">
              <svg className="h-6 w-6 text-blue-500 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
              <span>This is the grant of a license, not a transfer of title.</span>
            </div>
          </div>
        </section>

        {/* Section 3 */}
        <section className="mb-10">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">3. Disclaimer</h2>
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded">
            <div className="flex">
              <svg className="h-5 w-5 text-yellow-400 mt-1 mr-3" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              <p className="text-sm text-yellow-700">
                The materials on this website are provided on an "as is" basis. We make no warranties, expressed or implied, and disclaim all other warranties including, without limitation, implied warranties or conditions of merchantability and fitness for a particular purpose.
              </p>
            </div>
          </div>
        </section>

        {/* Section 4 */}
        <section className="mb-10">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">4. Limitations</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">Time Limitations</h3>
              <p className="text-gray-600">Claims must be filed within 30 days of the incident.</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">Liability</h3>
              <p className="text-gray-600">We shall not be held liable for any damages arising from the use or inability to use the materials.</p>
            </div>
          </div>
        </section>

        {/* Section 5 */}
        <section className="mb-10">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">5. Revisions</h2>
          <p className="text-gray-600 leading-relaxed">
            We may revise these Terms of Service at any time without notice. By using this website, you agree to be bound by the current version of these terms.
          </p>
        </section>

        {/* Section 6 */}
        <section>
          <h2 className="text-xl font-semibold text-gray-800 mb-4">6. Contact</h2>
          <div className="bg-gray-50 rounded-lg p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <p className="text-gray-600 mb-2 sm:mb-0">Have questions about our Terms of Service?</p>
            <a
              href="mailto:legal@easypay.com"
              className="inline-flex items-center text-blue-600 hover:text-blue-500"
            >
              <svg className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
                  d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              legal@easypay.com
            </a>
          </div>
        </section>
      </div>
    </div>
    </>
  );
};

export default TermsAndCondition;
