import { useState, useEffect } from "react";
import { Link } from "react-router-dom";

const HeroSection = () => {
  const images = [
    'https://t4.ftcdn.net/jpg/09/62/99/73/360_F_962997352_diaeWiS7YgB2fcM6Tkd6It9Tma6KOC4n.jpg',
    'https://static.wixstatic.com/media/105900_6abc9e4ad3244839808b3077075ac035~mv2_d_3242_2161_s_2.jpg/v1/fill/w_640,h_346,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/105900_6abc9e4ad3244839808b3077075ac035~mv2_d_3242_2161_s_2.jpg',
    'https://static1.squarespace.com/static/5342fb92e4b0907609b1bf65/53472596e4b08984da50d020/67a2bd19e64b7f30ba7cc926/1743025878015/Build+Strong+3.jpg?format=1500w',
  ];
  const [current, setCurrent] = useState(0);
  const [openFAQ, setOpenFAQ] = useState(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % images.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [images.length]);

  const faqs = [
    {
      id: 'faq1',
      question: 'How does EasyPay calculate salaries?',
      answer: 'EasyPay uses salary structures, attendance, and deduction rules to automatically compute net salaries and generate payslips accurately.'
    },
    {
      id: 'faq2',
      question: 'Can employees view and download their payslips?',
      answer: 'Yes, employees can securely log in and view/download their payslips directly from their dashboard anytime.'
    },
    {
      id: 'faq3',
      question: 'How customizable is the payroll structure?',
      answer: 'EasyPay allows full customization of payroll components such as basic pay, allowances, bonuses, and deductions to suit different company policies and roles.'
    },
    {
      id: 'faq4',
      question: 'Is payroll data secure with EasyPay?',
      answer: 'Yes, EasyPay follows strict security standards with encrypted data, role-based access, and audit trails to ensure data confidentiality.'
    }
  ];

  return (
 <main className="bg-white text-gray-800">
  <div className="relative w-full h-screen overflow-hidden">
    {images.map((src, index) => (
      <div
        key={index}
        className={`absolute top-0 left-0 w-full h-full transition-opacity duration-1000 ease-in-out ${
          index === current ? 'opacity-100 z-10' : 'opacity-0 z-0'
        }`}
      >
        <img
          src={src}
          alt={`Slide ${index + 1}`}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30 flex items-center justify-center px-6">
          <div className="text-center max-w-2xl">
            <h3 className="text-3xl md:text-4xl font-bold text-white leading-snug drop-shadow-lg mb-4">
              Simplify Payroll. Empower Employees.
            </h3>
            <p className="text-base md:text-lg text-gray-200 mb-6 drop-shadow-md">
              All-in-one payroll and employee management system designed for modern businesses.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link
                to="/login"
                className="px-6 py-3 bg-indigo-600 text-white font-medium rounded-md hover:bg-indigo-700 transition duration-300 shadow"
              >
                Get Started
              </Link>
              <Link
                to="/about"
                className="px-6 py-3 border border-white text-white font-medium rounded-md hover:bg-white hover:text-indigo-700 transition duration-300 shadow"
              >
                Learn More
              </Link>
            </div>
          </div>
        </div>
      </div>
    ))}
  </div>


      <section className="py-16 text-center bg-white">
        <h2 className="text-3xl font-bold mb-4">Why Choose EasyPay?</h2>
        <p className="max-w-3xl mx-auto text-gray-600 text-lg">
          EasyPay is a comprehensive payroll management solution designed to simplify salary processing,
          employee management, attendance tracking, and compliance. With accurate calculations, timely payments,
          and seamless reporting, each user role—Admin, HR Manager, or Employee—gets their own secure dashboard.
        </p>
      </section>

      
      <section className="bg-gradient-to-r from-gray-100 to-gray-200 py-16">
        <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { title: 'Quick Payroll', desc: 'Generate salaries and payslips instantly with just a few clicks.', btn: 'Get Started' },
            { title: 'Attendance Tracker', desc: 'Monitor employee attendance and leave records in real-time.', btn: 'Explore' },
            { title: 'Secure Access', desc: 'Provide role-based login to ensure data privacy and control.', btn: 'Get Started' }
          ].map((card, index) => (
            <div key={index} className="bg-white rounded-xl shadow p-6 text-center hover:shadow-lg transition">
              <h3 className="text-xl font-semibold mb-2">{card.title}</h3>
              <p className="text-gray-600 mb-4">{card.desc}</p>
              <Link to="/login" className="inline-block bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">{card.btn}</Link>
            </div>
          ))}
        </div>
      </section>

    
 <section className="bg-white py-16">
  <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
    <div className="text-center">
      <img
        src="https://cdn.prod.website-files.com/63d3d637345b1fbedf237dc4/669447873dc19067eae8e84f_API.png"
        alt="Modern Payroll Illustration"
        className="rounded-lg shadow-lg max-w-md mx-auto"
      />
    </div>

  
    <div className="text-center md:text-left">
      <h3 className="text-3xl font-bold mb-4">Smart, Simple & Secure Payroll</h3>
      <p className="text-gray-700 mb-4">
        EasyPay automates salary generation, tax computation, and payslip delivery to minimize manual effort
        and maximize accuracy.
      </p>
      <p className="text-gray-700 mb-6">
        With seamless controls and full transparency, HR managers and employees enjoy a stress-free payroll
        experience.
      </p>
      <Link
        to="/login"
        className="inline-block border border-indigo-600 text-indigo-600 px-5 py-2 rounded hover:bg-indigo-600 hover:text-white transition"
      >
        Start Now
      </Link>
    </div>
  </div>
</section>


      <section className="bg-gray-100 py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
          <p className="text-gray-600 mb-12">
            Have questions? We're here to help. Explore the most common questions about EasyPay.
          </p>
        </div>
        <div className="max-w-4xl mx-auto space-y-6">
          {faqs.map(({ id, question, answer }) => (
            <div
              key={id}
              className="border border-gray-200 rounded-lg shadow-sm overflow-hidden transition-all duration-300"
            >
              <button
                onClick={() => setOpenFAQ(openFAQ === id ? null : id)}
                className="w-full px-6 py-5 bg-white text-left flex items-center justify-between group hover:bg-indigo-50 transition duration-200"
              >
                <span className="text-base font-semibold text-gray-800">{question}</span>
                <svg
                  className={`w-5 h-5 text-gray-500 transform transition-transform duration-300 group-hover:text-indigo-600 ${
                    openFAQ === id ? 'rotate-180' : ''
                  }`}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              <div
                className={`px-6 text-gray-700 transition-all duration-300 ease-in-out ${
                  openFAQ === id ? 'max-h-96 py-4' : 'max-h-0 overflow-hidden'
                }`}
              >
                <p className="text-sm leading-relaxed">{answer}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

     
      <footer className="bg-gray-800 text-gray-200 py-6">
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm mb-2 md:mb-0">
            © {new Date().getFullYear()} EasyPay. All rights reserved.
          </p>
          <div className="flex space-x-4">
            <Link to="/privacy-policy" className="hover:text-white text-sm">Privacy Policy</Link>
            <Link to="/terms-of-service" className="hover:text-white text-sm">Terms of Service</Link>
            <Link to="/contact" className="hover:text-white text-sm">Contact Us</Link>
          </div>
        </div>
      </footer>
    </main>
  );
};

export default HeroSection;
