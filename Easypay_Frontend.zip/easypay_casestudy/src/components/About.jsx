import React from "react";
import Navbar from "./Navbar";

const About = () => {
  return (
    <>
      <Navbar />
      <br/>
      <div className="flex flex-col-reverse md:flex-row items-center max-w-6xl mx-auto px-6 py-16">
        <div className="md:w-1/2 md:pr-10">
        
          <span className="text-sm text-indigo-600 font-semibold uppercase tracking-wider">
            About Us
          </span>
          <h2 className="mt-3 text-4xl font-bold text-gray-900 leading-tight">
            Empowering Payroll Simplicity with <span className="text-indigo-600">EasyPay</span>
          </h2>
          <p className="mt-6 text-gray-700 text-lg leading-relaxed">
            EasyPay is a modern payroll and HR solution built to streamline and automate your organization's salary processes, employee management, and leave tracking. 
            Whether you're a small business or a large enterprise, our intuitive platform simplifies everything from payslip generation to real-time analytics.
          </p>
          <p className="mt-4 text-gray-700 text-lg">
            Our mission is to deliver a user-friendly experience for HR teams, managers, and employees—ensuring accurate, timely, and transparent payroll every time. 
            With EasyPay, compliance, reporting, and payroll operations become stress-free.
          </p>
        </div>

        {/* Image Section */}
        <div className="md:w-1/2 mb-10 md:mb-0">
          <img
            src="https://cdn-icons-png.flaticon.com/512/3062/3062634.png"
            alt="Payroll illustration"
            className="w-full max-w-md mx-auto"
          />
        </div>
      </div>
    </>
  );
};

export default About;
