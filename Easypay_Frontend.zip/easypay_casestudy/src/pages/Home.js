import React from 'react'
import Navbar from '../components/Navbar'
import HeroSection from '../components/HeroSection'

export const Home = () => {
  return (
    <div>
    <div className="pt-20">
        <Navbar/>
        </div>
        <HeroSection/>
    </div>
  )
}
